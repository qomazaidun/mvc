<script src="<?= BASEURL ?>/js/jquery.min.js"></script>
<script src="<?= BASEURL ?>/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/bs5/dt-1.12.1/datatables.min.js"></script>

<script>
  $(document).ready( function () {
    $('#table_id').DataTable({
        paging: true,
        ordering: true,
        info: true
    });
    

} );
</script>
</body>
</html>