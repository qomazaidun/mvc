<?php
function encr($code){
$method = "AES-128-CTR";
$key = 'b867543tybcc678ytrhhhh787jQRedkiyuytrWBpedsJLKfgAf';
$iv = "abvfgrtyjhd567aa";
$encript = openssl_encrypt($code,$method,$key,0,$iv);

return $encript;
}


function decr($code){
    $method = "AES-128-CTR";
    $key = 'b867543tybcc678ytrhhhh787jQRedkiyuytrWBpedsJLKfgAf';
    $iv = "abvfgrtyjhd567aa";
    $encript = openssl_decrypt($code,$method,$key,0,$iv);

    return $encript;
}


