<div class="container mt-5 mb-3">
<?php $urut = 1; ?>
<div class="card">
    <div class="card-body">
<div class="table-responsive">
<table id="table_id" class="table table-bordered table-hover fw-bold">
    <thead class="text-center">
        <tr>
            <th>No.</th>
            <th class="text-center">NISM</th>
            <th class="text-center">NAMA SANTRI</th>
            <th class="text-center">Alamat</th>
        </tr>
    </thead>
    <tbody class="text-end">
    <?php foreach ($data['nama'] as $dt):?>
        <tr>
            <td><?= $urut++?></td>
            <td><?= $dt['nism']?></td>
            <td><?= $dt['nama_santri']?></td>
            <td><?= $dt['kecamatan']?></td>
            
        </tr>
        <?php endforeach; ?>
        
    </tbody>
</table>
</div>
</div>
</div> 
</div>
