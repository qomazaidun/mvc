<?php

class Home extends Controller {

    public function index(){

        //parameter yang dikirim
        $data['judul'] = 'Home';
        $data['nama'] = $this->model('data_models')->getUser();

        //menambahkan tempalte header
        $this->view('_templates/header',$data);
        //body
        $this->view('home/index',$data);
        //footer
        $this->view('_templates/footer');

    }

}