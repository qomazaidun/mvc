<?php

//url pusat
define('BASEURL', 'http://localhost/MVC/public');

//database alamat
define('HOSTNAME', 'localhost');
define('USER', 'root');
define('PASS', '');
define('DB_DATA', 'data');
define('DB_ADMIN', 'admin');