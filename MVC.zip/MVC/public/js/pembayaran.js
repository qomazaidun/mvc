var nism = document.getElementById('nism');
var nama = document.getElementById('nama');
var ta = document.getElementById('ta');
var transaksi = document.getElementById('transaksi');
var harga = document.getElementById('harga');
var qty = document.getElementById('qty');
var tgl = document.getElementById('tgl');
var metode = document.getElementById('metode');
var submit = document.getElementById('submit');
var terbayar = document.getElementById('terbayar');
var tanggungan = document.getElementById('tanggungan');
var total = document.getElementById('total');

submit.addEventListener('click', function(){
    if (qty.value == "" || tgl.value == ""){
        alert('Isi QTY dan Tanggal juga!');
    }else {
        kali = qty.value * harga.value;
        res = kali + terbayar.value;
            if(res < jj){
                console.log("tidak terlalu");
                
            }else{
                alert('Pembayaran terlalu banyak! Silahkan ulangi dan teliti');
            }

            
    }
}

);
