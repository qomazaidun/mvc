<?php

class Database{
    private $host = HOSTNAME;
    private $user = USER;
    private $pass = PASS;
    private $db_name = DB_DATA;

    private $db; //database hendler
    private $stmt;

    public function __construct()
    {
        $dsn = "mysql:host=$this->host;dbname=$this->db_name";

        $option =[
            PDO::ATTR_PERSISTENT =>true,
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ];

        try
        {
            $this->db = new PDO($dsn, $this->user,$this->pass,$option);

        }catch(PDOException $e){
            die($e->getMessage());
        }


    }

    //query untuk databasenya

    public  function query($query)
    {
        $this->stmt = $this->db->prepare($query);

    }

    

    //query untuk bind

    public function bind($parameter, $value, $type = null)
    {
       if(is_null($type)){

        switch(true){
            case is_int($value):
                $type = PDO::PARAM_INT;
                break;
            case is_bool($value):
                $type = PDO::PARAM_BOOL;
                break;
            case is_null($value):
                $type = PDO::PARAM_NULL;
                break;
            default :
            $type = PDO::PARAM_STR;
            


        }
       }
       $this->stmt->bindValue($parameter, $value, $type);


    }


    public function execute()
    {
       $this->stmt->execute();
    }

    //tampil data banyak

    public function resultset()
    {
       $this->execute();
       return $this->stmt->fetchAll(PDO::FETCH_ASSOC);
    }


 //tampil satu
    public function singel()
    {
       $this->execute();
       return $this->stmt->fetch(PDO::FETCH_ASSOC);
    }

    

}
