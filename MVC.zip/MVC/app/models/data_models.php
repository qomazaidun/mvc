<?php

class data_models{

    private $table = 'tbl_data';
    private $db;



    public function __construct()
    {
        $this->db = new Database;
    }

    public function getUser()
    {

        $this->db->query("SELECT * FROM $this->table");
        return $this->db->resultset();
        
    }


}